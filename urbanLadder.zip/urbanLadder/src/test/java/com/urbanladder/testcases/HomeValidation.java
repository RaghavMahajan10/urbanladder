package com.urbanladder.testcases;

import org.testng.annotations.Test;

public class HomeValidation extends BaseTest {


@Test(priority=1)	
	public void testHome() throws Exception
	{
	  hp.homePage();
	}
}
