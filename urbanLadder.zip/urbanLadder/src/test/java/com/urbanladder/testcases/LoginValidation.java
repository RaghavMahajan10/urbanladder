package com.urbanladder.testcases;

import org.testng.annotations.Test;

public class LoginValidation extends BaseTest {

	@Test(priority=4)
	public void testLogin() throws Exception
	{
	  lp.login();
	}
}
