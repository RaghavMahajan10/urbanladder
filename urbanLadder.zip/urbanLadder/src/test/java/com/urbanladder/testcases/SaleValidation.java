package com.urbanladder.testcases;

import org.testng.annotations.Test;

public class SaleValidation extends BaseTest{

	@Test(priority=3)
	public void testSale() throws Exception
	{
	
		sp.product();
	}
}
