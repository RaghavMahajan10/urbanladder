package com.urbanladder.testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.urbanladder.excel.ReadExcel;
import com.urbanladder.pages.AddToCart;
import com.urbanladder.pages.HomePage;
import com.urbanladder.pages.LoginPage;
import com.urbanladder.pages.SalePage;
import com.urbanladder.pages.SelectFurniture;
import com.urbanladder.utils.DriverQuit;
import com.urbanladder.utils.DriverSetup;
import com.urbanladder.utils.Reports;


public class BaseTest {

	WebDriver driver;
	static LoginPage lp;
	static HomePage hp;
	static SelectFurniture sf;
	static SalePage sp;
	static AddToCart atc;
	static DriverQuit ds;
	@BeforeSuite 
	public void setBrowser() throws Exception
	{
		  driver=DriverSetup.createDriver("chrome");
		  Reports.startTest();
		  ReadExcel.readExcel();
		  lp=new LoginPage(driver);
		  hp=new HomePage(driver);
		  sf=new SelectFurniture(driver);
		  sp=new SalePage(driver);
		  atc=new AddToCart(driver);
		  ds=new DriverQuit(driver);
	}
	@AfterSuite
	public void close()
	{
		Reports.endTest();
	  ds.closeBrowser();
	}

}
