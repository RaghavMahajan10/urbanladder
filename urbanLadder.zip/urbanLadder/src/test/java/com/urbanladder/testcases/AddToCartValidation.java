package com.urbanladder.testcases;

import org.testng.annotations.Test;

public class AddToCartValidation extends BaseTest{
	@Test(priority=5)
	public void testAddTOCart() throws Exception
	{
		atc.clickOnProduct();
	}

}
