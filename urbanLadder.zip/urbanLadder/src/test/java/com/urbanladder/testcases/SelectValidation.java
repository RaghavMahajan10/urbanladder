package com.urbanladder.testcases;

import org.testng.annotations.Test;

public class SelectValidation extends BaseTest {

	@Test(priority=2)
	public void testSelect() throws Exception
	{
		sf.selectIt();
	}
}
