package com.urbanladder.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverSetup {

	 static WebDriver driver;
	
	public static  WebDriver  createDriver(String browser)  {
		  File file = new File(System.getProperty("user.dir")+"\\src\\main\\java\\com\\urbanladder\\config\\configure.properties");
			FileInputStream fileInput = null;
			try {
				fileInput = new FileInputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			Properties prop = new Properties();
			
			try {
				prop.load(fileInput);
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		if (browser.equalsIgnoreCase(prop.getProperty("browserChrome"))) {
		   System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(45, TimeUnit.SECONDS);
			driver.get(prop.getProperty("url"));
		} else if (browser.equalsIgnoreCase(prop.getProperty("browserFirefox"))) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(45, TimeUnit.SECONDS);
			driver.get(prop.getProperty("url"));
		} else 
		{
			System.out.println("invalid options");
		}
		return driver;
	}

}
