package com.urbanladder.utils;

import org.openqa.selenium.WebDriver;

public class DriverQuit {

  
	WebDriver driver;
	public DriverQuit(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public  void closeBrowser()
	{	
		driver.close();
	}
}
