package com.urbanladder.excel;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.urbanladder.config.Variable;

public class ReadExcel extends Variable {
	
	public static void readExcel() throws Exception {
		// it set the file path
		file = new File(pathRead);
		fileInputStream = new FileInputStream(file);
		workbook = new XSSFWorkbook(fileInputStream);
		// it will get the sheet
		sheet = workbook.getSheetAt(0);
		// it fetch the row
		row = sheet.getRow(0);

		// it fecth the data from excel at particular row and column
		email = row.getCell(0).getStringCellValue();
		password =row.getCell(1).getStringCellValue();
	 
	}



}
