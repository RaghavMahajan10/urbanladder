package com.urbanladder.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
public class Variable {
	public static String pathRead = System.getProperty("user.dir") + "\\testData\\readData.xlsx";
	public static String pathWrite = System.getProperty("user.dir") + "\\testData\\writeData.xlsx";
	public static String email;
	public static String password;
	public static String pathScreenshot = System.getProperty("user.dir") + "/Screenshot/screenshot";
	public static  ExtentTest test;
	public static  ExtentReports report;
	public static File file;
	public static FileInputStream fileInputStream;
	public static FileOutputStream fileOutputStream;
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static XSSFRow row;
	
	public static String sofa="sofa";
	public static XSSFCell col;
	public static String productUrl="https://www.urbanladder.com/products/search?filters%5Bmaterial%5D%5B%5D=Leather&filters%5Bavailability%5D%5B%5D=In+Stock+Only&sort=price_asc&keywords=sofa";
	//---------------------------------------Login xpath-----------------------------------------------------
	public static By target1=By.xpath("//header/div[1]/div[1]/section[3]/ul[1]/li[2]/span[1]/*[1]");
	public static By target2=By.xpath("//a[contains(text(),'Log In')]");
	public static By emailXpath=By.xpath("//div[@id='password-credentials']//input[@id='spree_user_email']");
	public static By passwordXpath=By.xpath("//body/div[@id='login_dialog']/div[@id='authentication_popup']/div[1]/div[1]/div[2]/div[3]/form[1]/div[1]/div[1]/div[1]/input[1]");
	public static By clickLogin=By.xpath("//input[@id='ul_site_login']");
	//--------------------------------------product Select xpath-------------------------------------------
	public static By search = By.xpath("//input[@id='search']");
	public static By checkbox =By.xpath("//input[@id='filters_availability_In_Stock_Only']");
	public static By dropdown =By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]");
	public static By lowToHigh =By.xpath("//li[contains(text(),'Price: Low to High')]");
	public static By material =By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/ul[1]/li[6]/div[1]/div[1]");
	public static By leather =By.xpath("//input[@id='filters_material_Leather']");
	public static By add = By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[3]/ul[1]/li[3]/div[1]/a[1]/img[1]");
    // ------------------------------------Sale product xpath-----------------------------------------------
	public static By saleButton=By.xpath("//span[contains(text(),'Sale')]");
    public static By productButton=By.xpath("//a[contains(text(),'Deals of the Week')]");
   // -------------------------------------Add to cart xpath----------------------------------------------------
    public static By searchResults_xpath=By.xpath("//div[@id='search-results']/div[1]/h2/text()");
    public static By clickOnProduct_xpath=By.xpath("//div[@id='search-results']/div[3]/ul/li[1]/div/a[2]");
    public static By scroll_xpath=By.xpath("//h2[@class=\'with-stroke module-header\']");
    public static By clickAddToCart_xpath=By.xpath("//button[@id='add-to-cart-button']");
    public static By emptyCart_xpath=By.xpath("//p[@class='empty_msg']");

}
