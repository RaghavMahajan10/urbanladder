package com.urbanladder.pages;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;
import com.urbanladder.config.Variable;
import com.urbanladder.utils.Screenshot;

public class HomePage extends Variable {

	WebDriver driver;
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	public void  homePage() throws Exception
	{
		
		driver.getCurrentUrl();
		Screenshot.takeScreenshot(driver);
		String title =driver.getTitle();
		if(title.equals("Furniture Online: Buy Home Wooden Furniture Online In India At Best Price - Urban Ladder - Urban Ladder"))
		{
		test.log(LogStatus.PASS, "Navigated to the specified URL");
		}
		else
		{
			test.log(LogStatus.FAIL, "Not Navigated to the specified URL");
		}
	}
}
